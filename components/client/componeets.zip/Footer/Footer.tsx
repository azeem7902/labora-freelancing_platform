import React from 'react';
import styles from './Footer.module.css';

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.column}>
          <div className={styles.brand}>Labora</div>
          <p>Building exceptional digital experiences for businesses worldwide.</p>
        </div>
        <div className={styles.column}>
          <h4>Quick Links</h4>
          <ul>
            <li>Home</li>
            <li>About Us</li>
            <li>Services</li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Services</h4>
          <ul>
            <li>Web Design</li>
            <li>Web Development</li>
            <li>App Development</li>
          </ul>
        </div>
        <div className={styles.column}>
          <h4>Contact Us</h4>
          <p>Email: info@labora.com</p>
          <p>Phone: +1 (234) 567-890</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;