import React from 'react';
import styles from './Header.module.css';
import FontAwesomeIcon from '@/corecomponents/FontAwesomeIcon';
import { SearchIcon, BellIcon } from '../../../icons';

const Header = () => {
  return (
    <header className={styles.header}>
      <div className={styles.welcome}>
        <h2>Welcome, Jane Smith</h2>
        <p>Manage hires for Tech Innovations Ltd.</p>
      </div>
      <div className={styles.actions}>
        <div className={styles.searchBar}>
          <FontAwesomeIcon icon={SearchIcon} />
          <input type="text" placeholder="Search freelancers..." />
        </div>
        <FontAwesomeIcon icon={BellIcon} />
        <div className={styles.profileIcon}>JS</div>
      </div>
    </header>
  );
};

export default Header;